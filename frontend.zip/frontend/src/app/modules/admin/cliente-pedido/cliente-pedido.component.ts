import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-pedido',
  templateUrl: './cliente-pedido.component.html',
  styleUrl: './cliente-pedido.component.css'
})
export class ClientePedidoComponent {

}
