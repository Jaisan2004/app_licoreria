import { Component } from '@angular/core';

@Component({
  selector: 'app-proveedores-crud',
  templateUrl: './proveedores-crud.component.html',
  styleUrl: './proveedores-crud.component.css'
})
export class ProveedoresCrudComponent {

}
