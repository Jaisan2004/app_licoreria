import { Component } from '@angular/core';

@Component({
  selector: 'app-productos-crud',
  templateUrl: './productos-crud.component.html',
  styleUrl: './productos-crud.component.css'
})
export class ProductosCrudComponent {

}
