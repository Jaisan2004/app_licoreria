import { Component } from '@angular/core';

@Component({
  selector: 'app-cliente-crud',
  templateUrl: './cliente-crud.component.html',
  styleUrl: './cliente-crud.component.css'
})
export class ClienteCrudComponent {

}
