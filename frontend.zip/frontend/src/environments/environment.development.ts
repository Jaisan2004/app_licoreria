export const environment = {
    endpoint: 'http://localhost:8080/'
};
