package co.edu.ue.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.ue.model.Direccione;

public interface IDireccione extends JpaRepository<Direccione, Integer>{

}
