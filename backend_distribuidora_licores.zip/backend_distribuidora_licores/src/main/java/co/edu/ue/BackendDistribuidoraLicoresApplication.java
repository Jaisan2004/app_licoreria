package co.edu.ue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendDistribuidoraLicoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendDistribuidoraLicoresApplication.class, args);
	}

}
