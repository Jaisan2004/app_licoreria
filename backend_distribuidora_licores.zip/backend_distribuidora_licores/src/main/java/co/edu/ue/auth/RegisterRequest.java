package co.edu.ue.auth;

public class RegisterRequest {

}
