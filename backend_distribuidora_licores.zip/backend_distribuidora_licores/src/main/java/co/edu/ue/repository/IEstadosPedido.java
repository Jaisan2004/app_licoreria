package co.edu.ue.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import co.edu.ue.model.EstadosPedido;

public interface IEstadosPedido extends JpaRepository<EstadosPedido, Integer>{

}
