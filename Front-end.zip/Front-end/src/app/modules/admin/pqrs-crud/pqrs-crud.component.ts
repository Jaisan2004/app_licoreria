import { Component } from '@angular/core';

@Component({
  selector: 'app-pqrs-crud',
  templateUrl: './pqrs-crud.component.html',
  styleUrl: './pqrs-crud.component.css'
})
export class PqrsCrudComponent {

}
