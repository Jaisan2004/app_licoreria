import { Component } from '@angular/core';

@Component({
  selector: 'app-clientes-crud',
  templateUrl: './clientes-crud.component.html',
  styleUrl: './clientes-crud.component.css'
})
export class ClientesCrudComponent {

}
